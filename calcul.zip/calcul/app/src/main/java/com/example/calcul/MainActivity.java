package com.example.calcul;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import org.mariuszgromada.math.mxparser.*;
import org.mariuszgromada.math.mxparser.mathcollection.Calculus;
import org.mariuszgromada.math.mxparser.parsertokens.CalculusOperator;

import android.icu.util.IslamicCalendar;
import android.media.VolumeShaper;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity{
    private EditText display;
    private Object calculate;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.input);
        display.setShowSoftInputOnFocus(false);

        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getString(R.string.display).equals(display.getText().toString())){
                    display.setText("");
                }
            }
        });

    }

    private void updateText(String strToAdd){
        String oldStr = display.getText().toString();
        int curcorPos = display.getSelectionStart();
        String leftStr = oldStr.substring(0, curcorPos);
        String rightStr = oldStr.substring(curcorPos);
        if (getString(R.string.display).equals(display.getText().toString())){
            display.setText(strToAdd);
            display.setSelection(curcorPos + 1);
        }else{
            display.setText(String.format("%s%s%s",leftStr, strToAdd, rightStr));
            display.setSelection(curcorPos + 1);

        }
    }

    public void zeroBTN(View view){
        updateText("0");

    }
    public void oneBTN(View view){
        updateText("1");
    }
    public void twoBTN(View view){
        updateText("2");
    }
    public void threeBTN(View view){
        updateText("3");
    }
    public void fourBTN(View view){
        updateText("4");
    }
    public void fiveBTN(View view){
        updateText("5");
    }
    public void sixBTN(View view){
        updateText("6");
    }
    public void sevenBTN(View view){
        updateText("7");
    }
    public void eiqhtBTN(View view){
        updateText("8");
    }
    public void nineBTN(View view){
        updateText("9");
    }
    public void addBTN(View view){
        updateText("+");
    }
    public void subtractBTN(View view){
        updateText("-");
    }
    public void multiplyBTN(View view){
        updateText("*");
    }
    public void divideBTN(View view){
        updateText("/");
    }
    public void exponentBTN(View view){
        updateText("^");
    }
    public void pointBTN(View view){
        updateText(".");
    }
    public void equalBTN(View view){
        String userExp = display.getText().toString();

        userExp = userExp.replaceAll("/", "/");
        userExp = userExp.replaceAll("x", "*");

        Exception exp = new Exception(userExp);

        String result = String.valueOf(calculate);

        display.setText(result);
        display.setSelection(result.length());
    }
    public void clearBTN(View view){
        display.setText("");
    }
    public void parenthesesBTN(View view){
        int curcorPos = display.getSelectionStart();
        int openParentheses = 0;
        int closeParentheses = 0;
        int textLen = display.getText().length();

        for (int i=0; i < curcorPos; i++){
            if (display.getText().toString().substring(i, i+1).equals("(")){
                openParentheses +=1;
            }
            if (display.getText().toString().substring(i, i+1).equals(")")){
                closeParentheses +=1;
            }
        }
        if (openParentheses == closeParentheses || display.getText().toString().substring(textLen-1,textLen).equals("(")){
            updateText("(");
            display.setSelection(curcorPos + 1);
        }else if (closeParentheses < openParentheses && !display.getText().toString().substring(textLen-1,textLen).equals("(")){
            updateText(")");
        }
        display.setSelection(curcorPos + 1);
    }
    public void plusMInusBTN(View view){
        updateText("+/-");
    }

}
